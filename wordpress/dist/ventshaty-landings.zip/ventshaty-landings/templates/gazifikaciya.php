<?php
/**
 * Шаблон собран wordpress/build.py из index.html — не правьте вручную,
 * меняйте HTML в корне репозитория и пересоберите плагин.
 */
defined( 'ABSPATH' ) || exit;
$vsh_u = esc_url( VSH_URL );
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php vsh_head_meta( 'Вентиляция для газового котла — вентшахты.рф', 'Вентшахта для газового котла: инженерный проект по СП 402.1325800.2018 и требованиям Мособлгаза, монтаж и герметичное примыкание к кровле с гарантией 2 года.' ); ?>
<?php wp_head(); ?>
</head>
<body <?php body_class( 'vsh-landing' ); ?>>
<?php wp_body_open(); ?>

<!-- ============================================================
     0. Первый экран
     H1 — ключевая фраза. Подзаголовок по 4U:
     польза (смонтируем под ваш дом) · уникальность (все каналы
     в одном объёме, двухконтурное утепление) · конкретика
     (1 м², 2 года) · срочность (за 7 дней).
     ============================================================ -->
<section class="section hero">
  <div class="container hero-grid">

    <div class="hero-text">
      <span class="eyebrow-pill">Сергиев Посад и Московская область</span>
      <h1 class="h1">Вентиляция для газового котла в частном доме</h1>
      <p class="lead">Спроектируем и смонтируем вентшахту под ваш дом за 7 дней: все каналы дома сводим в один объём менее 1 м², двухконтурное утепление, гарантия 2 года на примыкание к кровле по договору.</p>

      <div class="hero-actions">
        <a class="btn btn--primary" href="#zayavka">Рассчитать шахту под мой дом</a>
        <a class="btn btn--ghost" href="tel:+74951197285">+7 (495) 119-72-85</a>
      </div>

      <ul class="hero-facts">
        <li>Работаем с жестью с 1993 года</li>
        <li>Своё производство</li>
        <li>Две бригады: инженеры и кровельщики</li>
      </ul>
    </div>

    <div class="hero-media">
      <figure class="hero-shot hero-shot--ours">
        <picture>
          <source type="image/jpeg" srcset="<?php echo $vsh_u; ?>assets/img/gas-ours-640.jpg 640w, <?php echo $vsh_u; ?>assets/img/gas-ours-960.jpg 960w, <?php echo $vsh_u; ?>assets/img/gas-ours-1440.jpg 1440w" sizes="(max-width: 900px) 100vw, 520px">
          <img src="<?php echo $vsh_u; ?>assets/img/gas-ours-960.jpg" width="1440" height="1080" fetchpriority="high" decoding="async" alt="Вентшахта в фальцевой обшивке с дымником на кровле кирпичного дома">
        </picture>
        <figcaption class="shot-label shot-label--ours">Наш вариант</figcaption>
      </figure>
      <figure class="hero-shot hero-shot--econom">
        <picture>
          <source type="image/jpeg" srcset="<?php echo $vsh_u; ?>assets/img/gas-usual-640.jpg 640w, <?php echo $vsh_u; ?>assets/img/gas-usual-960.jpg 960w" sizes="(max-width: 900px) 40vw, 240px">
          <img src="<?php echo $vsh_u; ?>assets/img/gas-usual-640.jpg" width="1080" height="810" decoding="async" alt="Неутеплённая сэндвич-труба на фасаде деревянного дома">
        </picture>
        <figcaption class="shot-label shot-label--econom">Эконом-вариант</figcaption>
      </figure>
    </div>

  </div>
</section>


<!-- ============================================================
     1. Галерея «эконом-вариант / наш вариант»
     ============================================================ -->
<section class="section section--tint section--gallery" id="gallery">
  <div class="container">

    <header class="block-head block-head--narrow">
      <span class="eyebrow-pill">Вентиляция газового котла</span>
      <h2 class="h2">Эконом-вариант и наш — в чём разница</h2>
      <p class="lead">Задача одна: сделать вентиляцию котельной. Оба варианта примут газовщики — формально это одна и та же труба. Разница в том, что будет дальше: опрокинется ли тяга, погаснет ли котёл и куда уйдёт газ при утечке.</p>
    </header>

    <div class="tabs" role="tablist" aria-label="Объекты">
      <button type="button" class="tab is-active" role="tab" id="tab-0" aria-controls="objpanel" aria-selected="true" data-object="0">Каркасный дом, Сергиев Посад</button>
      <button type="button" class="tab" role="tab" id="tab-1" aria-controls="objpanel" aria-selected="false" tabindex="-1" data-object="1">Кирпичный дом, Хотьково</button>
      <button type="button" class="tab" role="tab" id="tab-2" aria-controls="objpanel" aria-selected="false" tabindex="-1" data-object="2">Объект 3</button>
    </div>

    <div class="compare" id="objpanel" role="tabpanel" aria-labelledby="tab-0">

      <article class="compare-card">
        <div class="compare-media" data-media="usual">
          <picture>
            <source type="image/jpeg" srcset="<?php echo $vsh_u; ?>assets/img/gas-usual-640.jpg 640w, <?php echo $vsh_u; ?>assets/img/gas-usual-960.jpg 960w, <?php echo $vsh_u; ?>assets/img/gas-usual-1080.jpg 1080w" sizes="(max-width: 860px) 100vw, 600px">
            <img src="<?php echo $vsh_u; ?>assets/img/gas-usual-960.jpg" width="1080" height="810" loading="lazy" decoding="async" alt="Неутеплённая сэндвич-труба на фасаде деревянного дома">
          </picture>
          <span class="media-badge media-badge--econom"><span class="media-dot"></span>Эконом-вариант</span>
        </div>
        <div class="compare-body">
          <h3 class="h3">Сэндвич-труба без расчёта</h3>
          <ul class="marks">
            <li class="mark"><span class="mark-icon mark-icon--econom" aria-hidden="true">–</span><span>Труба заканчивается ниже зоны ветрового подпора — при ветре с этой стороны тягу может опрокинуть</span></li>
            <li class="mark"><span class="mark-icon mark-icon--econom" aria-hidden="true">–</span><span>Без утепления: металл остывает, внутри конденсат, снаружи наледь и потёки</span></li>
            <li class="mark"><span class="mark-icon mark-icon--econom" aria-hidden="true">–</span><span>Высоту и сечение берут по месту, без расчёта под конкретный дом</span></li>
            <li class="mark"><span class="mark-icon mark-icon--econom" aria-hidden="true">–</span><span>Если тяга опрокинулась, вытяжка работает как приток: при утечке газ пойдёт в жилые комнаты, а не в атмосферу</span></li>
          </ul>
        </div>
      </article>

      <article class="compare-card compare-card--ours">
        <div class="compare-media" data-media="ours">
          <picture>
            <source type="image/jpeg" srcset="<?php echo $vsh_u; ?>assets/img/gas-ours-640.jpg 640w, <?php echo $vsh_u; ?>assets/img/gas-ours-960.jpg 960w, <?php echo $vsh_u; ?>assets/img/gas-ours-1440.jpg 1440w" sizes="(max-width: 860px) 100vw, 600px">
            <img src="<?php echo $vsh_u; ?>assets/img/gas-ours-960.jpg" width="1440" height="1080" loading="lazy" decoding="async" alt="Вентшахта в фальцевой обшивке с дымником на кровле кирпичного дома">
          </picture>
          <span class="media-badge media-badge--ours"><span class="media-dot"></span>Наш вариант</span>
        </div>
        <div class="compare-body">
          <h3 class="h3">Шахта по расчёту, с двухконтурным утеплением</h3>
          <ul class="marks">
            <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Выводим выше зоны ветрового подпора — тягу не опрокидывает, котёл не гаснет от ветра</span></li>
            <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Двухконтурное утепление и отвод конденсата — тяга держится и в мороз</span></li>
            <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Высоту и сечение считаем под ваш дом: мощность котла, высота, расположение относительно конька</span></li>
            <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Обычно ведём шахту в объёме дома; если не выходит — по фасаду, в обшивке под цвет кровли</span></li>
            <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Примыкание к кровле делаем сами — кровельные работы наша компетенция</span></li>
          </ul>
        </div>
      </article>

    </div>

    <div class="cta-bar">
      <p class="cta-bar-text">Посчитаем высоту и сечение шахты под ваш котёл, дом и кровлю — по расчёту, а не на глаз.</p>
      <a class="btn btn--primary" href="#zayavka">Получите проект вентиляции</a>
    </div>

  </div>
</section>


<!-- ============================================================
     1.5 Сколько стоит
     ============================================================ -->
<section class="section" id="cena">
  <div class="container split split--start">

    <div class="split-main">
      <div class="block-head">
        <h2 class="h2">Сколько стоит вентшахта</h2>
        <p class="lead">Точную цену называем после расчёта: она зависит от этажности, мощности котла, типа кровли и стадии строительства. Порядок сумм такой.</p>
      </div>

      <div class="price-list">
        <div class="price-row">
          <div class="price-row-text">
            <h3 class="h4">Одноэтажный дом</h3>
            <p>Шахта под ключ: проект, изготовление, монтаж, примыкание к кровле, дымник.</p>
          </div>
          <p class="price-value">от 250&nbsp;000&nbsp;₽</p>
        </div>

        <div class="price-row">
          <div class="price-row-text">
            <h3 class="h4">Два этажа или мансарда</h3>
            <p>Шахта выше, модулей больше, примыкание сложнее — отсюда разница в цене.</p>
          </div>
          <p class="price-value">от 360&nbsp;000&nbsp;₽</p>
        </div>

        <div class="price-row">
          <div class="price-row-text">
            <h3 class="h4">Шахта и вентиляция всего дома</h3>
            <p>Все каналы дома сводим в один объём менее 1 м² и выводим одной шахтой.</p>
          </div>
          <p class="price-value">от 460&nbsp;000&nbsp;₽</p>
        </div>
      </div>

      <p class="field-hint">Цена фиксируется в договоре после выезда и расчёта. Выезд и расчёт ни к чему вас не обязывают.</p>
    </div>

    <div class="value-card">
      <p class="value-card-title">Что входит в стоимость</p>
      <ul class="marks">
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Выезд, замер и инженерный расчёт под ваш дом</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Изготовление модулей на своём производстве</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Доставка на объект</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Монтаж шахты и двухконтурное утепление</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Примыкание к кровле и дымник</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Гарантия 2 года на примыкание по договору</span></li>
      </ul>
      <a class="btn btn--primary btn--wide" href="#zayavka">Узнать цену для своего дома</a>
    </div>

  </div>
</section>


<!-- ============================================================
     2. Текстовый блок: сдать или сделать один раз
     ============================================================ -->
<section class="section">
  <div class="prose">
    <h2 class="h2">Вентиляцию под газ можно сдать — а можно забыть о ней на 20 лет</h2>
    <p class="lead">Инспектор проверяет, что вентиляция есть. Качество он не проверяет: будет ли задувать котёл и не потянет ли газ в жилые комнаты — это видно только во время ЧП.</p>
    <p class="lead">В котельной обычно не живут, поэтому проблему замечают не сразу. Дальше это ваша эксплуатация, а не зона инспектора: начнёт задувать котёл — придётся переделывать. Переделки всегда сложнее и дороже монтажа.</p>
    <p class="lead">Мы считаем высоту и сечение шахты под ваш дом по СП 402.1325800.2018 и требованиям Мособлгаза, утепляем в два контура и сами делаем примыкание к кровле. Возвращаться к узлу не придётся.</p>
    <p class="hand">Решать вам — разницу вы видели выше</p>
  </div>
</section>


<!-- ============================================================
     2.5 Как мы работаем — пять шагов
     ============================================================ -->
<section class="section section--tint">
  <div class="container">

    <div class="block-head block-head--narrow">
      <h2 class="h2">Как проходит работа</h2>
      <p class="lead">От звонка до готовой шахты — пять шагов. Монтаж начинаем от 7 дней с момента согласования проекта.</p>
    </div>

    <ol class="steps">
      <li class="step">
        <span class="step-num">1</span>
        <h3 class="h4">Заявка и разговор</h3>
        <p>Вячеслав, мастер компании, перезвонит и спросит про дом: этажность, котёл, стадия строительства. Уже на этом этапе скажем порядок цены.</p>
      </li>
      <li class="step">
        <span class="step-num">2</span>
        <h3 class="h4">Выезд и замер</h3>
        <p>Смотрим котельную, кровлю и расположение относительно конька. Без этого честно посчитать высоту и сечение нельзя.</p>
      </li>
      <li class="step">
        <span class="step-num">3</span>
        <h3 class="h4">Проект и договор</h3>
        <p>Считаем шахту по СП 402.1325800.2018 и требованиям Мособлгаза. Цену и сроки фиксируем в договоре, дальше они не меняются.</p>
      </li>
      <li class="step">
        <span class="step-num">4</span>
        <h3 class="h4">Изготовление</h3>
        <p>Модули шахты и дымник делаем на своём производстве в Сергиевом Посаде — под размеры вашего дома, а не из того, что нашлось на складе.</p>
      </li>
      <li class="step">
        <span class="step-num">5</span>
        <h3 class="h4">Монтаж и сдача</h3>
        <p>Шахту ставит бригада монтажников, примыкание к кровле делают кровельщики. На выходе — акт и гарантия 2 года на стык по договору.</p>
      </li>
    </ol>

  </div>
</section>


<!-- ============================================================
     3. Чем мы отличаемся от частного мастера с Авито
     ============================================================ -->
<section class="section section--tint">
  <div class="container split split--start">

    <div class="split-main">
      <header class="block-head">
        <h2 class="h2">Чем мы отличаемся от частного мастера с Авито</h2>
        <p class="lead">Мастер приедет и выведет трубу за день. Мы сначала считаем, потом монтируем — и отвечаем за кровлю вокруг шахты.</p>
      </header>

      <div class="num-grid">

        <div class="num-card">
          <span class="num">01</span>
          <div class="num-text">
            <h3 class="h4">Сначала инженерный проект</h3>
            <p>Считаем сечения и тягу под ваш котёл и дом. Шахту выводим только после расчёта — не «на глаз» по месту.</p>
          </div>
        </div>

        <div class="num-card">
          <span class="num">02</span>
          <div class="num-text">
            <h3 class="h4">Вентиляция дополняет фасад</h3>
            <p>Обшивка и дымник в цвет кровли и отделки. Узел выглядит как часть дома, а не как труба, прикрученная к стене.</p>
          </div>
        </div>

        <div class="num-card">
          <span class="num">03</span>
          <div class="num-text">
            <h3 class="h4">Гарантия 2 года от протечек</h3>
            <p>Стык кровли и шахты герметизируем по своей технологии. Гарантия прописана в договоре — 2 года.</p>
          </div>
        </div>

        <div class="num-card">
          <span class="num">04</span>
          <div class="num-text">
            <h3 class="h4">Две бригады: инженеры и кровельщики</h3>
            <p>Мы не только вентиляционщики, но и профессиональные кровельщики. Проект, шахта и кровля — в одном подряде, без подрядчиков со стороны.</p>
          </div>
        </div>

      </div>
    </div>

    <aside class="founder">
      <div class="founder-photo">
        <!-- TODO: подставить фото основателя (вертикальный кадр, ~840×1120) в assets/img/founder.jpg -->
        <div class="img-placeholder" data-placeholder="Фото основателя, вертикальный кадр"></div>
      </div>
      <div class="founder-name">
        <p class="founder-title">Григорий Корноухов</p>
        <p class="caption">Основатель компании</p>
      </div>
      <p class="hand founder-quote">Говорят, мы «заморачиваемся». Просто мы делаем вентиляцию, которая годами работает и не создаёт проблем, — а не ту, на которую «закроют глаза» газовщики</p>
    </aside>

  </div>
</section>


<!-- ============================================================
     3.5 Объекты и отзывы
     ЗАГЛУШКИ: нужны фото объектов и реальные отзывы с именами.
     Тексты отзывов не придуманы — в карточках стоят подсказки,
     какой именно отзыв туда просить у заказчика.
     ============================================================ -->
<section class="section" id="obyekty">
  <div class="container">

    <div class="block-head block-head--narrow">
      <h2 class="h2">Объекты и отзывы</h2>
      <p class="lead">Дома в Московской области, где стоят наши шахты. У каждой — свой расчёт: высота, сечение, тип кровли.</p>
    </div>

    <div class="gallery">
      <figure class="gallery-cell">
        <div class="img-placeholder" data-placeholder="Фото объекта 1"></div>
        <figcaption class="gallery-caption">[ЗАГЛУШКА: тип дома, посёлок]</figcaption>
      </figure>
      <figure class="gallery-cell">
        <div class="img-placeholder" data-placeholder="Фото объекта 2"></div>
        <figcaption class="gallery-caption">[ЗАГЛУШКА: тип дома, посёлок]</figcaption>
      </figure>
      <figure class="gallery-cell">
        <div class="img-placeholder" data-placeholder="Фото объекта 3"></div>
        <figcaption class="gallery-caption">[ЗАГЛУШКА: тип дома, посёлок]</figcaption>
      </figure>
      <figure class="gallery-cell">
        <div class="img-placeholder" data-placeholder="Фото объекта 4"></div>
        <figcaption class="gallery-caption">[ЗАГЛУШКА: тип дома, посёлок]</figcaption>
      </figure>
      <figure class="gallery-cell">
        <div class="img-placeholder" data-placeholder="Фото объекта 5"></div>
        <figcaption class="gallery-caption">[ЗАГЛУШКА: тип дома, посёлок]</figcaption>
      </figure>
      <figure class="gallery-cell">
        <div class="img-placeholder" data-placeholder="Фото объекта 6"></div>
        <figcaption class="gallery-caption">[ЗАГЛУШКА: тип дома, посёлок]</figcaption>
      </figure>
    </div>

    <div class="reviews">
      <figure class="review review--empty">
        <blockquote>[ЗАГЛУШКА: отзыв заказчика, который ставил шахту до финишной отделки — что получилось спрятать в объём дома]</blockquote>
        <figcaption><span class="review-name">[Имя]</span><span class="review-meta">[тип дома, посёлок]</span></figcaption>
      </figure>
      <figure class="review review--empty">
        <blockquote>[ЗАГЛУШКА: отзыв заказчика, который живёт с шахтой вторую-третью зиму — как ведёт себя котёл в ветер и мороз]</blockquote>
        <figcaption><span class="review-name">[Имя]</span><span class="review-meta">[тип дома, посёлок]</span></figcaption>
      </figure>
      <figure class="review review--empty">
        <blockquote>[ЗАГЛУШКА: отзыв заказчика, у которого мы делали и шахту, и кровельные работы — про стык и отсутствие протечек]</blockquote>
        <figcaption><span class="review-name">[Имя]</span><span class="review-meta">[тип дома, посёлок]</span></figcaption>
      </figure>
    </div>

  </div>
</section>


<!-- ============================================================
     4. Почему у нас заказывают, зная, что дороже
     ============================================================ -->
<section class="section">
  <div class="container split split--center">

    <div class="split-main split-main--gap">
      <h2 class="h2">Почему у нас заказывают, зная, что дороже</h2>
      <p class="lead">Причина одна: к нашей вентшахте не возвращаются. Она дополняет фасад дома и работает 20+ лет — вместе с домом, а не до первой зимы.</p>

      <div class="value-card">
        <p class="value-card-title">Что вы покупаете за эту разницу</p>
        <ul class="marks marks--wide">
          <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span><strong>Шахту не задувает обратной тягой</strong> — котёл работает ровно и при боковом ветре, и в оттепель.</span></li>
          <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span><strong>Вентиляция дополняет фасад</strong> — обшивка и дымник в цвет кровли, а не труба поверх готовой отделки.</span></li>
          <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span><strong>Риски эксплуатации закрыты нами</strong> — конденсат, наледь, протечка на стыке с кровлей. Гарантия 2 года по договору.</span></li>
          <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span><strong>Один раз и на 20+ лет</strong> — без переделок по готовому фасаду и без второго подрядчика.</span></li>
        </ul>
      </div>
    </div>

    <div class="mosaic">
      <!-- TODO: три реальных фото объектов -->
      <div class="mosaic-cell mosaic-cell--wide">
        <div class="img-placeholder" data-placeholder="Котельная: котёл и вытяжка"></div>
      </div>
      <div class="mosaic-cell">
        <div class="img-placeholder" data-placeholder="Шахта и дымник на фасаде"></div>
      </div>
      <div class="mosaic-cell">
        <div class="img-placeholder" data-placeholder="Воздуховоды в котельной"></div>
      </div>
    </div>

  </div>
</section>


<!-- ============================================================
     5. Три коротких видео
     ============================================================ -->
<section class="section section--dark">
  <div class="container video-wrap">

    <header class="video-head">
      <div class="block-head video-head-main">
        <p class="caption caption--on-dark">Подробнее о подходе</p>
        <h2 class="h2 h2--on-dark">Три коротких видео — три минуты вашего времени</h2>
        <p class="lead lead--on-dark">Показываем на объектах, как считаем шахту, как герметизируем стык с кровлей и как узел выглядит на готовом доме.</p>
      </div>
      <p class="hand hand--on-dark">Без монтажа под музыку — просто работа</p>
    </header>

    <div class="video-grid">

      <article class="video-card" data-video>
        <div class="video-media">
          <!-- TODO: кадр-превью видео в assets/img/video-1.jpg -->
          <div class="img-placeholder img-placeholder--dark" data-placeholder="Кадр из видео 1"></div>
          <span class="video-play" aria-hidden="true"><span class="video-play-tri"></span></span>
          <span class="video-time">1:02</span>
        </div>
        <div class="video-body">
          <h3 class="h4 h4--on-dark">Как мы считаем шахту под ваш котёл</h3>
          <p class="video-text">Что смотрим в доме перед проектом: мощность котла, высота, сечения каналов.</p>
        </div>
      </article>

      <article class="video-card" data-video>
        <div class="video-media">
          <!-- TODO: кадр-превью видео в assets/img/video-2.jpg -->
          <div class="img-placeholder img-placeholder--dark" data-placeholder="Кадр из видео 2"></div>
          <span class="video-play" aria-hidden="true"><span class="video-play-tri"></span></span>
          <span class="video-time">0:58</span>
        </div>
        <div class="video-body">
          <h3 class="h4 h4--on-dark">Стык с кровлей: почему не течёт</h3>
          <p class="video-text">Наша технология примыкания — та, на которую даём гарантию 2 года по договору.</p>
        </div>
      </article>

      <article class="video-card" data-video>
        <div class="video-media">
          <!-- TODO: кадр-превью видео в assets/img/video-3.jpg -->
          <div class="img-placeholder img-placeholder--dark" data-placeholder="Кадр из видео 3"></div>
          <span class="video-play" aria-hidden="true"><span class="video-play-tri"></span></span>
          <span class="video-time">1:04</span>
        </div>
        <div class="video-body">
          <h3 class="h4 h4--on-dark">Готовый узел на доме</h3>
          <p class="video-text">Как шахта и дымник выглядят на фасаде через несколько зим после монтажа.</p>
        </div>
      </article>

    </div>
  </div>
</section>


<!-- ============================================================
     5.5 Гарантия и договор
     ============================================================ -->
<section class="section" id="garantiya">
  <div class="container split split--start">

    <div class="split-main">
      <div class="block-head">
        <h2 class="h2">Что записано в договоре</h2>
        <p class="lead">Работаем по договору: цена и сроки фиксируются после расчёта и дальше не меняются. Гарантия на примыкание тоже прописана, а не обещана на словах.</p>
      </div>

      <div class="num-grid">
        <div class="num-card">
          <span class="num">01</span>
          <div class="num-text">
            <h3 class="h4">Гарантия 2 года на примыкание</h3>
            <p>Стык кровли и шахты — наша зона ответственности. Протечка в гарантийный срок устраняется за наш счёт.</p>
          </div>
        </div>
        <div class="num-card">
          <span class="num">02</span>
          <div class="num-text">
            <h3 class="h4">Фиксированная цена</h3>
            <p>Сумма определяется после выезда и расчёта. Доплат «нашли ещё работы» по ходу монтажа не будет.</p>
          </div>
        </div>
        <div class="num-card">
          <span class="num">03</span>
          <div class="num-text">
            <h3 class="h4">Сроки в договоре</h3>
            <p>От 7 дней с момента согласования проекта. Дату монтажа фиксируем, а не двигаем.</p>
          </div>
        </div>
        <div class="num-card">
          <span class="num">04</span>
          <div class="num-text">
            <h3 class="h4">Один подрядчик на всё</h3>
            <p>Проект, изготовление, монтаж и кровельные работы — по одному договору. Перекладывать ответственность не на кого.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="doc-card">
      <div class="doc-shot">
        <!-- TODO: скан обезличенного договора или гарантийного талона -->
        <div class="img-placeholder" data-placeholder="Скан договора, обезличенный"></div>
      </div>
      <p class="field-hint">Покажем договор до начала работ — можно прочитать целиком и обсудить формулировки.</p>
    </div>

  </div>
</section>


<!-- ============================================================
     5.6 Производство
     ============================================================ -->
<section class="section section--tint" id="proizvodstvo">
  <div class="container split split--center">

    <div class="split-main split-main--gap">
      <h2 class="h2">Своё производство в Сергиевом Посаде</h2>
      <p class="lead">Мы не перепродаём готовые трубы. Модули шахты, дымники, колпаки и приточные клапаны делаем сами — из жести, с которой работаем с 1993 года.</p>
      <p class="lead">Поэтому шахта получается не «ближайшего подходящего размера», а под конкретный дом: нужную высоту и сечение мы просто изготавливаем.</p>

      <dl class="stats">
        <div class="stat">
          <dt class="stat-value">1993</dt>
          <dd class="stat-label">год, с которого работаем с жестью</dd>
        </div>
        <div class="stat">
          <dt class="stat-value">6500+</dt>
          <dd class="stat-label">объектов в Московской области</dd>
        </div>
        <div class="stat">
          <dt class="stat-value">2</dt>
          <dd class="stat-label">бригады: инженеры и кровельщики</dd>
        </div>
      </dl>
    </div>

    <div class="mosaic">
      <!-- TODO: три фото производства -->
      <div class="mosaic-cell mosaic-cell--wide">
        <div class="img-placeholder" data-placeholder="Цех: листогиб, раскрой жести"></div>
      </div>
      <div class="mosaic-cell">
        <div class="img-placeholder" data-placeholder="Готовые модули шахты"></div>
      </div>
      <div class="mosaic-cell">
        <div class="img-placeholder" data-placeholder="Бригада на объекте"></div>
      </div>
    </div>

  </div>
</section>


<!-- ============================================================
     6. Частые вопросы
     ============================================================ -->
<section class="section section--faq">
  <div class="container split split--start split--faq">

    <div class="faq-intro">
      <h2 class="h2">Частые вопросы</h2>
      <p class="lead">Отвечает Вячеслав, мастер компании. Если вопроса здесь нет — позвоните, ответим по вашему дому.</p>
      <a class="phone" href="tel:+74951197285">+7 (495) 119-72-85</a>
    </div>

    <div class="faq-list">

      <details class="faq-item">
        <summary class="faq-summary">
          <span>Можно ли смонтировать шахту, когда дом уже отделан?</span>
          <span class="faq-plus" aria-hidden="true">+</span>
        </summary>
        <div class="faq-answer">Да, но объём работ будет больше: придётся вскрывать участок кровли и подшивку. Дешевле и аккуратнее выходит, если позвать нас до финишной отделки — тогда шахта прячется в объём дома, а снаружи остаётся только выход над кровлей.</div>
      </details>

      <details class="faq-item">
        <summary class="faq-summary">
          <span>Не потечёт ли кровля в месте, где выходит шахта?</span>
          <span class="faq-plus" aria-hidden="true">+</span>
        </summary>
        <div class="faq-answer">Нет, протечек не будет. Примыкание делаем сами, по своей технологии — кровельные работы одна из наших сильных компетенций. На стык даём гарантию 2 года, она прописана в договоре.</div>
      </details>

      <details class="faq-item">
        <summary class="faq-summary">
          <span>Сколько времени занимает работа?</span>
          <span class="faq-plus" aria-hidden="true">+</span>
        </summary>
        <div class="faq-answer">От 7 дней с момента согласования проекта. Сначала выезд и расчёт, затем изготовление модулей на своём производстве, потом монтаж — шахта и примыкание к кровле.</div>
      </details>

      <details class="faq-item">
        <summary class="faq-summary">
          <span>Зачем проект, если газовщики его не требуют?</span>
          <span class="faq-plus" aria-hidden="true">+</span>
        </summary>
        <div class="faq-answer">Проверку можно пройти и без проекта. Проект нужен вам, а не инспектору: он показывает, хватит ли воздуха котлу и не будет ли обратной тяги при ветре. Мы считаем по СП 402.1325800.2018 и требованиям Мособлгаза — и только потом выводим шахту.</div>
      </details>

      <details class="faq-item">
        <summary class="faq-summary">
          <span>Сколько места шахта займёт в доме?</span>
          <span class="faq-plus" aria-hidden="true">+</span>
        </summary>
        <div class="faq-answer">Менее 1 м². Все каналы дома и вытяжку котельной мы сводим в один объём, поэтому по этажам не расходятся отдельные трубы.</div>
      </details>

      <details class="faq-item">
        <summary class="faq-summary">
          <span>Нужно ли электричество и обслуживание?</span>
          <span class="faq-plus" aria-hidden="true">+</span>
        </summary>
        <div class="faq-answer">Нет. Это естественная вентиляция: без моторов, фильтров и электричества. Ломаться в ней нечего, счёт за электричество не растёт.</div>
      </details>

      <details class="faq-item">
        <summary class="faq-summary">
          <span>Куда вы выезжаете?</span>
          <span class="faq-plus" aria-hidden="true">+</span>
        </summary>
        <!-- ЗАГЛУШКА: уточнить у клиента, выезжаете ли за пределы области и на каких условиях -->
        <div class="faq-answer">Работаем по Московской области, производство в Сергиевом Посаде. [ЗАГЛУШКА: уточнить, выезжаете ли за пределы области и на каких условиях]</div>
      </details>

    </div>
  </div>
</section>


<!-- ============================================================
     7. Заявка — точка, куда ведут все CTA страницы
     TODO: подключить отправку в CRM или на почту.
     Форма сейчас проверяет поля и показывает подтверждение,
     но данные никуда не уходят — см. sendLead() в main.js.
     ============================================================ -->
<section class="section section--tint" id="zayavka">
  <div class="container split split--start">

    <div class="form-intro">
      <h2 class="h2">Рассчитаем шахту под ваш дом</h2>
      <p class="lead">Оставьте телефон — Вячеслав, мастер компании, перезвонит и задаст несколько вопросов по дому. Расчёт и выезд ни к чему вас не обязывают.</p>
      <a class="phone" href="tel:+74951197285">+7 (495) 119-72-85</a>
      <p class="caption">info@krovmast.ru · Производство в Сергиевом Посаде</p>
    </div>

    <form class="lead-form" id="lead-form" novalidate>
      <div class="field">
        <label class="field-label" for="lead-name">Как к вам обращаться</label>
        <input class="field-input" type="text" id="lead-name" name="name" autocomplete="name" placeholder="Имя">
      </div>

      <div class="field">
        <label class="field-label" for="lead-phone">Телефон</label>
        <input class="field-input" type="tel" id="lead-phone" name="phone" autocomplete="tel" inputmode="tel" placeholder="+7 (___) ___-__-__" required aria-describedby="lead-phone-error">
        <p class="field-error" id="lead-phone-error" hidden>Впишите номер, по которому с вами можно связаться</p>
      </div>

      <!-- Ловушка для ботов: скрыта от людей, заполненную заявку сервер отбрасывает -->
      <div class="hp" aria-hidden="true">
        <label for="lead-website">Сайт</label>
        <input type="text" id="lead-website" name="website" tabindex="-1" autocomplete="off">
      </div>

      <div class="field">
        <label class="field-label" for="lead-stage">На какой стадии дом</label>
        <select class="field-input" id="lead-stage" name="stage">
          <option value="">Не выбрано</option>
          <option value="proekt">Проект, дом ещё не строится</option>
          <option value="korobka">Коробка готова, до отделки</option>
          <option value="otdelka">Идёт отделка</option>
          <option value="gotov">Дом готов, нужна вентиляция</option>
        </select>
        <p class="field-hint">До финишной отделки шахта обходится дешевле — поэтому спрашиваем.</p>
      </div>

      <label class="field-check">
        <input type="checkbox" id="lead-consent" name="consent" required>
        <!-- ЗАГЛУШКА: подставить ссылку на политику обработки персональных данных -->
        <span>Согласен на обработку персональных данных</span>
      </label>
      <p class="field-error" id="lead-consent-error" hidden>Без согласия мы не сможем вам перезвонить</p>

      <button class="btn btn--primary btn--wide" type="submit">Получить расчёт</button>
      <p class="field-hint">Перезваниваем в рабочее время, обычно в течение часа.</p>

      <p class="form-done" id="lead-done" hidden role="status">Заявка принята. Вячеслав перезвонит вам на указанный номер.</p>
    </form>

  </div>
</section>


<!-- ============================================================
     8. Футер
     ЗАГЛУШКИ: юрлицо, ИНН, адрес производства, политика ПДн.
     ============================================================ -->
<footer class="footer">
  <div class="container footer-grid">

    <div class="footer-brand">
      <p class="footer-mark">ВЕНТШАХТЫ.РФ</p>
      <p class="footer-text">Проектирование, производство и монтаж естественной вентиляции в частных домах. Семейное производство, работаем с жестью с 1993 года.</p>
    </div>

    <div class="footer-col">
      <p class="caption caption--on-dark">Связаться</p>
      <a class="footer-link footer-link--phone" href="tel:+74951197285">+7 (495) 119-72-85</a>
      <a class="footer-link" href="mailto:info@krovmast.ru">info@krovmast.ru</a>
      <a class="btn btn--primary" href="#zayavka">Оставить заявку</a>
    </div>

    <div class="footer-col">
      <p class="caption caption--on-dark">Где мы</p>
      <p class="footer-text">Производство — Сергиев Посад.<br>Работаем по Московской области.</p>
    </div>

    <div class="footer-col">
      <p class="caption caption--on-dark">Разделы</p>
      <a class="footer-link" href="#cena">Цены</a>
      <a class="footer-link" href="#obyekty">Объекты и отзывы</a>
      <a class="footer-link" href="#garantiya">Гарантия и договор</a>
      <a class="footer-link" href="#proizvodstvo">Производство</a>
    </div>

  </div>

  <div class="container footer-bottom">
    <p class="footer-legal">Вентшахты.рф · Проектирование, производство и монтаж вентиляции</p>
    <!-- TODO: подставить адрес политики обработки персональных данных -->
    <a class="footer-link" href="#">Политика обработки персональных данных</a>
  </div>
</footer>

<!-- Сквозная кнопка на мобильном: появляется, когда первый экран ушёл
     вверх, и прячется, когда человек долистал до формы -->
<div class="sticky-cta" id="sticky-cta" hidden>
  <a class="btn btn--ghost" href="tel:+74951197285">Позвонить</a>
  <a class="btn btn--primary" href="#zayavka">Оставить заявку</a>
</div>

<?php wp_footer(); ?>
</body>
</html>
