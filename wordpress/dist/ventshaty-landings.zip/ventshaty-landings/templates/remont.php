<?php
/**
 * Шаблон собран wordpress/build.py из remont.html — не правьте вручную,
 * меняйте HTML в корне репозитория и пересоберите плагин.
 */
defined( 'ABSPATH' ) || exit;
$vsh_u = esc_url( VSH_URL );
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php vsh_head_meta( 'Ремонт вентиляции в частном доме — вентшахты.рф', 'Ремонт вентиляции в частном доме: устраняем обратную тягу, конденсат, наледь и протечки на кровле. Инженерная диагностика, свои детали, гарантия по договору.' ); ?>
<?php wp_head(); ?>
</head>
<body <?php body_class( 'vsh-landing' ); ?>>
<?php wp_body_open(); ?>

<!-- ============================================================
     0. Первый экран — фото сразу, текст минимальный
     ============================================================ -->
<section class="section hero">
  <div class="container hero-grid">

    <div class="hero-text">
      <span class="eyebrow-pill">Сергиев Посад и Московская область</span>
      <h1 class="h1">Ремонт вентиляции в частном доме</h1>
      <p class="lead">Задувает котёл, конденсат и наледь, течёт кровля у трубы. Находим причину и устраняем — с гарантией по договору.</p>

      <div class="hero-actions">
        <a class="btn btn--primary" href="#zayavka">Вызвать на диагностику</a>
        <a class="btn btn--ghost" href="tel:+74951197285">+7 (495) 119-72-85</a>
      </div>

      <ul class="hero-facts">
        <li>С жестью с 1993 года</li>
        <li>Своё производство</li>
        <li>Инженеры и кровельщики</li>
      </ul>
    </div>

    <div class="hero-media">
      <figure class="hero-shot hero-shot--ours">
        <picture>
          <source type="image/jpeg" srcset="<?php echo $vsh_u; ?>assets/img/gas-ours-640.jpg 640w, <?php echo $vsh_u; ?>assets/img/gas-ours-960.jpg 960w, <?php echo $vsh_u; ?>assets/img/gas-ours-1440.jpg 1440w" sizes="(max-width: 900px) 100vw, 520px">
          <img src="<?php echo $vsh_u; ?>assets/img/gas-ours-960.jpg" width="1440" height="1080" fetchpriority="high" decoding="async" alt="Вентшахта по расчёту, с утеплением и дымником на кровле">
        </picture>
        <figcaption class="shot-label shot-label--ours">Как должно быть</figcaption>
      </figure>
      <figure class="hero-shot hero-shot--econom">
        <picture>
          <source type="image/jpeg" srcset="<?php echo $vsh_u; ?>assets/img/gas-usual-640.jpg 640w, <?php echo $vsh_u; ?>assets/img/gas-usual-960.jpg 960w" sizes="(max-width: 900px) 40vw, 240px">
          <img src="<?php echo $vsh_u; ?>assets/img/gas-usual-640.jpg" width="1080" height="810" decoding="async" alt="Неутеплённая труба без расчёта — частая причина проблем">
        </picture>
        <figcaption class="shot-label shot-label--econom">Проблема</figcaption>
      </figure>
    </div>

  </div>
</section>


<!-- ============================================================
     1. С чем к нам приходят — компактные карточки, одна строка
     ============================================================ -->
<section class="section section--tint" id="simptomy">
  <div class="container">

    <div class="block-head block-head--narrow">
      <h2 class="h2">С чем к нам приходят</h2>
    </div>

    <div class="symptoms symptoms--compact">
      <article class="symptom"><h3 class="h4">Задувает котёл</h3></article>
      <article class="symptom"><h3 class="h4">Конденсат и плесень</h3></article>
      <article class="symptom"><h3 class="h4">Наледь на трубе</h3></article>
      <article class="symptom"><h3 class="h4">Не тянет вытяжка</h3></article>
      <article class="symptom"><h3 class="h4">Течёт кровля у трубы</h3></article>
      <article class="symptom"><h3 class="h4">Самодельный узел</h3></article>
    </div>

    <div class="cta-bar">
      <p class="cta-bar-text">Найдём причину и устраним — с гарантией по договору.</p>
      <a class="btn btn--primary" href="#zayavka">На диагностику</a>
    </div>

  </div>
</section>


<!-- ============================================================
     2. Видео — как работаем
     Ссылки на ролики кладём в data-video-url каждой карточки.
     Пусто → карточка статичная (превью-заглушка). Как появятся
     ссылки (YouTube / VK / Rutube в embed-виде) — впишем сюда.
     ============================================================ -->
<section class="section section--dark" id="video">
  <div class="container video-wrap">

    <header class="video-head">
      <div class="block-head video-head-main">
        <p class="caption caption--on-dark">Видео с объектов</p>
        <h2 class="h2 h2--on-dark">Как мы находим причину и чиним</h2>
      </div>
      <p class="hand hand--on-dark">Реальная работа, без монтажа под музыку</p>
    </header>

    <div class="video-grid">

      <!-- Ролик канала ВЕНТШАХТЫ.РФ на Rutube (автор подтверждён).
           Превью берём у Rutube; если не загрузится — остаётся тёмная заглушка. -->
      <article class="video-card" data-video data-video-url="https://rutube.ru/play/embed/b97c45428732d9e93f0f1792b519d96e">
        <div class="video-media">
          <div class="img-placeholder img-placeholder--dark" data-placeholder=""></div>
          <img src="https://rutube.ru/api/video/b97c45428732d9e93f0f1792b519d96e/thumbnail/?redirect=1" alt="Две вентшахты на кирпичном доме — кадр из видео" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.remove()">
          <span class="video-play" aria-hidden="true"><span class="video-play-tri"></span></span>
        </div>
        <div class="video-body">
          <h3 class="h4 h4--on-dark">Две вентшахты на кирпичном доме и примыкание к черепице</h3>
        </div>
      </article>

      <aside class="video-card video-more">
        <div class="video-body">
          <h3 class="h4 h4--on-dark">Все ролики с наших объектов</h3>
          <p class="video-text">Монтаж шахт, примыкания к кровле, разбор ошибок — снимаем сами.</p>
          <a class="btn btn--primary" href="https://rutube.ru/channel/52346920/" target="_blank" rel="noopener">Смотреть на Rutube</a>
          <a class="btn btn--ghost btn--on-dark" href="https://www.youtube.com/@ventshahty/videos" target="_blank" rel="noopener">Канал на YouTube</a>
        </div>
      </aside>

    </div>
  </div>
</section>


<!-- ============================================================
     3. Как проходит ремонт — пять шагов, по строке
     ============================================================ -->
<section class="section">
  <div class="container">

    <div class="block-head block-head--narrow">
      <h2 class="h2">Как проходит ремонт</h2>
    </div>

    <ol class="steps">
      <li class="step">
        <span class="step-num">1</span>
        <h3 class="h4">Заявка</h3>
        <p>Мастер перезвонит и расспросит про симптомы.</p>
      </li>
      <li class="step">
        <span class="step-num">2</span>
        <h3 class="h4">Диагностика</h3>
        <p>Смотрим узел и кровлю, проверяем тягу.</p>
      </li>
      <li class="step">
        <span class="step-num">3</span>
        <h3 class="h4">Смета</h3>
        <p>Называем причину, цену и срок. Фиксируем в договоре.</p>
      </li>
      <li class="step">
        <span class="step-num">4</span>
        <h3 class="h4">Ремонт</h3>
        <p>Недостающие детали делаем на своём производстве.</p>
      </li>
      <li class="step">
        <span class="step-num">5</span>
        <h3 class="h4">Сдача</h3>
        <p>Проверяем тягу. Акт и гарантия по договору.</p>
      </li>
    </ol>

  </div>
</section>


<!-- ============================================================
     4. Цены
     ЗАГЛУШКА: платность диагностики.
     ============================================================ -->
<section class="section section--tint" id="cena">
  <div class="container split split--start">

    <div class="split-main">
      <div class="block-head">
        <h2 class="h2">Сколько стоит ремонт</h2>
        <p class="lead">Точную цену называем после диагностики. Порядок сумм такой.</p>
      </div>

      <div class="price-list">
        <div class="price-row">
          <div class="price-row-text"><h3 class="h4">Утепление, конденсат</h3></div>
          <p class="price-value">от 83&nbsp;000&nbsp;₽</p>
        </div>
        <div class="price-row">
          <div class="price-row-text"><h3 class="h4">Наращивание высоты, сечение</h3></div>
          <p class="price-value">от 102&nbsp;000&nbsp;₽</p>
        </div>
        <div class="price-row">
          <div class="price-row-text"><h3 class="h4">Ремонт примыкания к кровле</h3></div>
          <p class="price-value">от 110&nbsp;000&nbsp;₽</p>
        </div>
        <div class="price-row">
          <div class="price-row-text"><h3 class="h4">Переборка самодельного узла</h3></div>
          <p class="price-value">от 120&nbsp;000&nbsp;₽</p>
        </div>
      </div>

      <!-- ЗАГЛУШКА: платный ли выезд/диагностика -->
      <p class="field-hint">Диагностика: [ЗАГЛУШКА — бесплатно / фикс. сумма]. Цена ремонта фиксируется в договоре.</p>
    </div>

    <div class="value-card">
      <p class="value-card-title">Что входит</p>
      <ul class="marks">
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Диагностика и заключение по узлу</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Детали со своего производства</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Работы и проверка тяги</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Гарантия по договору</span></li>
      </ul>
      <a class="btn btn--primary btn--wide" href="#zayavka">Узнать цену</a>
    </div>

  </div>
</section>


<!-- ============================================================
     5. Чем отличаемся — 4 карточки по строке
     ============================================================ -->
<section class="section">
  <div class="container">
    <div class="block-head block-head--narrow">
      <h2 class="h2">Чем отличается наш ремонт</h2>
    </div>
    <div class="num-grid">
      <div class="num-card">
        <span class="num">01</span>
        <div class="num-text"><h3 class="h4">Инженерная диагностика</h3><p>Находим причину, а не глушим симптом.</p></div>
      </div>
      <div class="num-card">
        <span class="num">02</span>
        <div class="num-text"><h3 class="h4">Свои детали</h3><p>Оголовки и элементы делаем под ваш узел.</p></div>
      </div>
      <div class="num-card">
        <span class="num">03</span>
        <div class="num-text"><h3 class="h4">Кровельщики</h3><p>Примыкание переделываем сами, гарантия 2 года.</p></div>
      </div>
      <div class="num-card">
        <span class="num">04</span>
        <div class="num-text"><h3 class="h4">Договор</h3><p>Цена, срок и гарантия — на бумаге.</p></div>
      </div>
    </div>
  </div>
</section>


<!-- ============================================================
     6. Когда ремонт, а когда честнее заменить
     Кросс-ссылка на монтаж под ключ (index.html).
     ============================================================ -->
<section class="section section--tint">
  <div class="container split split--start">

    <div class="value-card">
      <p class="value-card-title">Ремонтируем</p>
      <ul class="marks marks--wide">
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Не хватает высоты или сечения</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Нет утепления — конденсат и наледь</span></li>
        <li class="mark"><span class="mark-icon mark-icon--good" aria-hidden="true">✓</span><span>Течёт примыкание, узел рабочий</span></li>
      </ul>
    </div>

    <div class="value-card value-card--plain">
      <p class="value-card-title">Честнее заменить</p>
      <ul class="marks marks--wide">
        <li class="mark"><span class="mark-icon mark-icon--dot" aria-hidden="true">–</span><span>Узел собран без расчёта целиком</span></li>
        <li class="mark"><span class="mark-icon mark-icon--dot" aria-hidden="true">–</span><span>Каналы сведены неправильно</span></li>
        <li class="mark"><span class="mark-icon mark-icon--dot" aria-hidden="true">–</span><span>Металл прогнил — латать нечего</span></li>
      </ul>
      <a class="btn btn--ghost btn--wide" href="<?php echo esc_url( vsh_opt( 'montazh_url' ) ); ?>">Монтаж шахты под ключ</a>
    </div>

  </div>
</section>


<!-- ============================================================
     7. Объекты — фото-галерея
     ЗАГЛУШКИ: реальные фото ремонта загрузить в assets/img.
     ============================================================ -->
<section class="section" id="obyekty">
  <div class="container">

    <div class="block-head block-head--narrow">
      <h2 class="h2">Наши объекты</h2>
    </div>

    <div class="gallery">
      <figure class="gallery-cell">
        <picture>
          <source type="image/jpeg" srcset="<?php echo $vsh_u; ?>assets/img/gas-ours-640.jpg 640w, <?php echo $vsh_u; ?>assets/img/gas-ours-960.jpg 960w" sizes="(max-width: 860px) 100vw, 400px">
          <img src="<?php echo $vsh_u; ?>assets/img/gas-ours-640.jpg" width="1440" height="1080" loading="lazy" decoding="async" alt="Вентшахта по расчёту на кровле">
        </picture>
        <figcaption class="gallery-caption">Шахта по расчёту, с утеплением</figcaption>
      </figure>
      <figure class="gallery-cell">
        <picture>
          <source type="image/jpeg" srcset="<?php echo $vsh_u; ?>assets/img/gas-usual-640.jpg 640w, <?php echo $vsh_u; ?>assets/img/gas-usual-960.jpg 960w" sizes="(max-width: 860px) 100vw, 400px">
          <img src="<?php echo $vsh_u; ?>assets/img/gas-usual-640.jpg" width="1080" height="810" loading="lazy" decoding="async" alt="Неутеплённая труба — типичная проблема">
        </picture>
        <figcaption class="gallery-caption">Проблемный узел без утепления</figcaption>
      </figure>
      <figure class="gallery-cell">
        <div class="img-placeholder" data-placeholder="Фото: примыкание к кровле"></div>
        <figcaption class="gallery-caption">[ЗАГЛУШКА: ремонт примыкания]</figcaption>
      </figure>
      <figure class="gallery-cell">
        <div class="img-placeholder" data-placeholder="Фото: узел после ремонта"></div>
        <figcaption class="gallery-caption">[ЗАГЛУШКА: после ремонта]</figcaption>
      </figure>
    </div>

  </div>
</section>


<!-- ============================================================
     8. Гарантия — 4 карточки по строке
     ЗАГЛУШКА: срок гарантии на прочие работы.
     ============================================================ -->
<section class="section section--tint" id="garantiya">
  <div class="container">
    <div class="block-head block-head--narrow">
      <h2 class="h2">Что в договоре</h2>
    </div>
    <div class="num-grid">
      <div class="num-card">
        <span class="num">01</span>
        <div class="num-text"><h3 class="h4">Гарантия 2 года на примыкание</h3><p>Протечку в срок устраняем за свой счёт.</p></div>
      </div>
      <div class="num-card">
        <span class="num">02</span>
        <!-- ЗАГЛУШКА: срок гарантии на прочие работы -->
        <div class="num-text"><h3 class="h4">Гарантия на работы</h3><p>На остальное — [ЗАГЛУШКА: срок].</p></div>
      </div>
      <div class="num-card">
        <span class="num">03</span>
        <div class="num-text"><h3 class="h4">Фиксированная цена</h3><p>Без доплат по ходу ремонта.</p></div>
      </div>
      <div class="num-card">
        <span class="num">04</span>
        <div class="num-text"><h3 class="h4">Один подрядчик</h3><p>Ремонт и кровля — по одному договору.</p></div>
      </div>
    </div>
  </div>
</section>


<!-- ============================================================
     9. Производство — коротко + цифры
     ЗАГЛУШКИ: фото производства.
     ============================================================ -->
<section class="section" id="proizvodstvo">
  <div class="container split split--center">

    <div class="split-main split-main--gap">
      <h2 class="h2">Детали делаем сами</h2>
      <p class="lead">Оголовки, утепление и элементы примыкания изготавливаем на своём производстве под ваш узел — не ждём «подходящий размер».</p>

      <dl class="stats">
        <div class="stat"><dt class="stat-value">1993</dt><dd class="stat-label">с этого года работаем с жестью</dd></div>
        <div class="stat"><dt class="stat-value">6500+</dt><dd class="stat-label">объектов в Подмосковье</dd></div>
        <div class="stat"><dt class="stat-value">2</dt><dd class="stat-label">бригады: инженеры и кровельщики</dd></div>
      </dl>
    </div>

    <div class="mosaic">
      <!-- TODO: фото производства -->
      <div class="mosaic-cell mosaic-cell--wide"><div class="img-placeholder" data-placeholder="Цех: раскрой жести"></div></div>
      <div class="mosaic-cell"><div class="img-placeholder" data-placeholder="Готовые оголовки"></div></div>
      <div class="mosaic-cell"><div class="img-placeholder" data-placeholder="Бригада на объекте"></div></div>
    </div>

  </div>
</section>


<!-- ============================================================
     10. FAQ — текст спрятан под спойлеры
     ============================================================ -->
<section class="section section--faq">
  <div class="container split split--start split--faq">

    <div class="faq-intro">
      <h2 class="h2">Частые вопросы</h2>
      <a class="phone" href="tel:+74951197285">+7 (495) 119-72-85</a>
    </div>

    <div class="faq-list">
      <details class="faq-item">
        <summary class="faq-summary"><span>Ремонт или замена?</span><span class="faq-plus" aria-hidden="true">+</span></summary>
        <div class="faq-answer">Чаще хватает устранить причину: утепление, высота, примыкание. Если узел неремонтопригоден — честно скажем и посчитаем новый.</div>
      </details>
      <details class="faq-item">
        <summary class="faq-summary"><span>Почему задувает котёл?</span><span class="faq-plus" aria-hidden="true">+</span></summary>
        <div class="faq-answer">Тягу опрокидывает ветром: труба ниже зоны подпора или занижено сечение. Считаем и выводим выше.</div>
      </details>
      <details class="faq-item">
        <summary class="faq-summary"><span>Откуда конденсат и наледь?</span><span class="faq-plus" aria-hidden="true">+</span></summary>
        <div class="faq-answer">Канал не утеплён. Ставим двухконтурное утепление и отвод конденсата — сырость и намерзание уходят.</div>
      </details>
      <details class="faq-item">
        <summary class="faq-summary"><span>Течёт кровля у трубы — к вам?</span><span class="faq-plus" aria-hidden="true">+</span></summary>
        <div class="faq-answer">Да. Примыкание переделываем сами, кровельные работы — наша компетенция. Гарантия на стык 2 года.</div>
      </details>
      <details class="faq-item">
        <summary class="faq-summary"><span>Сколько стоит?</span><span class="faq-plus" aria-hidden="true">+</span></summary>
        <!-- ЗАГЛУШКА -->
        <div class="faq-answer">Ремонт — от 83&nbsp;000&nbsp;₽, точную цену называем после выезда и фиксируем в договоре. Диагностика: [ЗАГЛУШКА].</div>
      </details>
    </div>
  </div>
</section>


<!-- ============================================================
     11. Заявка — форма общая с главной (assets/main.js)
     name="stage" сохранён, значения под ремонт.
     ============================================================ -->
<section class="section section--tint" id="zayavka">
  <div class="container split split--start">

    <div class="form-intro">
      <h2 class="h2">Запишитесь на диагностику</h2>
      <p class="lead">Оставьте телефон — мастер перезвонит. Диагностика ни к чему не обязывает.</p>
      <a class="phone" href="tel:+74951197285">+7 (495) 119-72-85</a>
      <p class="caption">info@krovmast.ru · Сергиев Посад</p>
    </div>

    <form class="lead-form" id="lead-form" novalidate>
      <div class="field">
        <label class="field-label" for="lead-name">Как к вам обращаться</label>
        <input class="field-input" type="text" id="lead-name" name="name" autocomplete="name" placeholder="Имя">
      </div>

      <div class="field">
        <label class="field-label" for="lead-phone">Телефон</label>
        <input class="field-input" type="tel" id="lead-phone" name="phone" autocomplete="tel" inputmode="tel" placeholder="+7 (___) ___-__-__" required aria-describedby="lead-phone-error">
        <p class="field-error" id="lead-phone-error" hidden>Впишите номер, по которому с вами можно связаться</p>
      </div>

      <!-- Ловушка для ботов: скрыта от людей, заполненную заявку сервер отбрасывает -->
      <div class="hp" aria-hidden="true">
        <label for="lead-website">Сайт</label>
        <input type="text" id="lead-website" name="website" tabindex="-1" autocomplete="off">
      </div>

      <div class="field">
        <label class="field-label" for="lead-stage">Что с вентиляцией</label>
        <select class="field-input" id="lead-stage" name="stage">
          <option value="">Не выбрано</option>
          <option value="obratnaya-tyaga">Задувает котёл</option>
          <option value="kondensat">Конденсат, наледь</option>
          <option value="slabaya-tyaga">Не тянет вытяжка</option>
          <option value="protechka">Течёт кровля у трубы</option>
          <option value="samodel">Самодельный узел</option>
          <option value="drugoe">Другое</option>
        </select>
      </div>

      <label class="field-check">
        <input type="checkbox" id="lead-consent" name="consent" required>
        <!-- ЗАГЛУШКА: ссылка на политику ПДн -->
        <span>Согласен на обработку персональных данных</span>
      </label>
      <p class="field-error" id="lead-consent-error" hidden>Без согласия мы не сможем вам перезвонить</p>

      <button class="btn btn--primary btn--wide" type="submit">Записаться на диагностику</button>
      <p class="field-hint">Перезваниваем обычно в течение часа.</p>

      <p class="form-done" id="lead-done" hidden role="status">Заявка принята. Мы перезвоним вам на указанный номер.</p>
    </form>

  </div>
</section>


<!-- ============================================================
     12. Футер
     ============================================================ -->
<footer class="footer">
  <div class="container footer-grid">

    <div class="footer-brand">
      <p class="footer-mark">ВЕНТШАХТЫ.РФ</p>
      <p class="footer-text">Проектирование, производство, монтаж и ремонт вентиляции в частных домах. Работаем с жестью с 1993 года.</p>
    </div>

    <div class="footer-col">
      <p class="caption caption--on-dark">Связаться</p>
      <a class="footer-link footer-link--phone" href="tel:+74951197285">+7 (495) 119-72-85</a>
      <a class="footer-link" href="mailto:info@krovmast.ru">info@krovmast.ru</a>
      <a class="btn btn--primary" href="#zayavka">Оставить заявку</a>
    </div>

    <div class="footer-col">
      <p class="caption caption--on-dark">Где мы</p>
      <p class="footer-text">Производство — Сергиев Посад.<br>Работаем по Московской области.</p>
    </div>

    <div class="footer-col">
      <p class="caption caption--on-dark">Разделы</p>
      <a class="footer-link" href="#simptomy">С чем приходят</a>
      <a class="footer-link" href="#video">Видео</a>
      <a class="footer-link" href="#cena">Цены</a>
      <a class="footer-link" href="<?php echo esc_url( vsh_opt( 'montazh_url' ) ); ?>">Монтаж под ключ</a>
    </div>

  </div>

  <div class="container footer-bottom">
    <p class="footer-legal">Вентшахты.рф · Ремонт и монтаж вентиляции</p>
    <!-- TODO: ссылка на политику ПДн -->
    <a class="footer-link" href="#">Политика обработки персональных данных</a>
  </div>
</footer>

<div class="sticky-cta" id="sticky-cta" hidden>
  <a class="btn btn--ghost" href="tel:+74951197285">Позвонить</a>
  <a class="btn btn--primary" href="#zayavka">На диагностику</a>
</div>

<?php wp_footer(); ?>
</body>
</html>
